# Codebook: Pakistan Empirical Governance & Resource Dataset (1990–2026)

**Principal Investigator:** Anam Sajjad (Department of Political Science, BZU Multan)
**ORCID:** 0009-0004-6169-1703 | **DOI:** 10.5281/zenodo.24054373

| Variable | Description | Source | Units |
| :--- | :--- | :--- | :--- |
| `year` | Calendar year | Official Surveys | Year |
| `energy_circular_debt_pkr_b` | Total sovereign circular debt in power & gas | Ministry of Energy, NEPRA | Billion PKR |
| `capacity_payments_pkr_b` | Guaranteed sovereign take-or-pay capacity payments | CPPA-G, NEPRA | Billion PKR |
| `live_water_storage_maf` | Total live reservoir carryover storage | IRSA, WAPDA | Million Acre-Feet (MAF) |
| `canal_conveyance_loss_pct` | Estimated transit seepage and conveyance loss | PIDA, WAPDA | Percentage (%) |
| `youth_population_under_30_m` | Population under age 30 | PBS 2023 Digital Census | Millions |
| `debt_servicing_tax_pct` | Sovereign debt service / Net Federal Revenue | State Bank of Pakistan | Percentage (%) |
| `it_services_export_usd_m` | Total IT and digital software export receipts | SBP, PSEB | Million USD |
