# Replication Package: Pakistan Is Not Poor, It Is Poorly Managed

This repository package provides empirical replication materials for the manuscript:
*Pakistan Is Not Poor, It Is Poorly Managed: An Empirical Investigation of Energy, Water, and Demographics in Pakistan*

- **Lead Author:** Anam Sajjad (BZU Multan) [ORCID: 0009-0004-6169-1703]
- **Co-Author:** M Yousaf (Emerson University Multan)
- **Permanent DOI:** [10.5281/zenodo.24054373](https://doi.org/10.5281/zenodo.24054373)
- **License:** Creative Commons Attribution 4.0 International (CC-BY 4.0)

## Files Included:
1. `pakistan_macro_empirical_dataset_1990_2024.csv` - Econometric time-series data.
2. `codebook_variable_definitions.md` - Complete variable descriptions, definitions, and official sources.
